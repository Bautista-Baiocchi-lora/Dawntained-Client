package org.bot.ui.management;

public enum InterfaceAction {
	LOAD_SERVER, SHOW_SERVER_SELECTOR, SHOW_LOGIN;
}
