package org.bot.ui.management;

public interface Manager {

	public void processActionRequest(InterfaceActionRequest request);

}
