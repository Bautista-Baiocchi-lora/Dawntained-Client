package org.bot.component.listeners;

import java.awt.Graphics2D;

/**
 * Created by Ethan on 6/28/2017.
 */
public interface PaintListener {

	public void render(Graphics2D graphics);

}