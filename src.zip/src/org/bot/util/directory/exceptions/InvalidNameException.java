package org.bot.util.directory.exceptions;

public class InvalidNameException extends Exception {

	private static final long serialVersionUID = 4139344206095457028L;

	public InvalidNameException(String exception) {
		super(exception);
	}

}
