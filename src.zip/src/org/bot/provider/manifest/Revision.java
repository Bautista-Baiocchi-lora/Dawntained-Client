package org.bot.provider.manifest;

public enum Revision {
	OSRS, $317, $474;
}
